def main():
    print(f'Hi')


if __name__ == '__main__':
    main()

